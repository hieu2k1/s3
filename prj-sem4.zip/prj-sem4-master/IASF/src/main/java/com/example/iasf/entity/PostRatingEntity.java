//package com.example.iasf.entity;
//
//public class PostRatingEntity {
//}
