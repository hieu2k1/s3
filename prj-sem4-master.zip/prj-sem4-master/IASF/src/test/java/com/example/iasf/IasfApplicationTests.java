package com.example.iasf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IasfApplicationTests {

	@Test
	void contextLoads() {
	}

}
