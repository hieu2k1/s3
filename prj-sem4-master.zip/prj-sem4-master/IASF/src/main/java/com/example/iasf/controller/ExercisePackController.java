package com.example.iasf.controller;

import com.example.iasf.entity.ExercisePackEntity;
import com.example.iasf.entity.PostEntity;
import com.example.iasf.service.ExerciseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Optional;

@Controller
public class ExercisePackController {
    @Autowired
    ExerciseService exerciseService;

    @GetMapping("/listexercise")
    private String listExercise(Model model) {
        List<ExercisePackEntity> exercises = exerciseService.getAll();
        model.addAttribute("exercises", exercises);
        return "listexercise";
    }

    @GetMapping("/createexercise")
    private String addExercise(Model model) {
        ExercisePackEntity exercisePackEntity = new ExercisePackEntity();
        model.addAttribute("exercise", exercisePackEntity);
        return "createexercise";
    }
    @PostMapping("/createexercise")
    public String addExercise(@ModelAttribute ExercisePackEntity exercisePackEntity) {
        exerciseService.createExercise(exercisePackEntity);
        return "redirect:/listexercise";
    }
    @GetMapping("/deleteexercise/{magoi}")
    public String deleteExercise(@PathVariable("magoi") int magoi, Model model) {
        exerciseService.deleteExercise(magoi);
        return "redirect:/listexercise";
    }

    @GetMapping("/editexercise/{magoi}")
    public String editExercise(@PathVariable("magoi") int magoi, Model model) {
        Optional<ExercisePackEntity> exerciseEdit = exerciseService.findExerciseById(magoi);
        exerciseEdit.ifPresent(exercise -> model.addAttribute("exercise", exercise));
        return "editexercise";
    }
}
