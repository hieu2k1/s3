package com.example.iasf.controller;

import com.example.iasf.entity.PostEntity;
import com.example.iasf.entity.UserEntity;
import com.example.iasf.service.PostService;
import com.example.iasf.service.UserServiceItf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class WebController {

    @Autowired
    UserServiceItf userServiceItf;

    @Autowired
    PostService postService;


    @GetMapping({"/", "index"})
    private String index() {
        return "index";
    }

    @GetMapping({ "indexuser"})
    private String indexuser() {
        return "indexuser";
    }

    @GetMapping("/user")
    private String user() {
        return "user";
    }

    @GetMapping("/ourteam")
    private String ourteam() {
        return "ourteam";
    }

    @GetMapping("/contact")
    private String contact() {
        return "contact";
    }

    @GetMapping("/home")
    private String home(Model model) {
        List<PostEntity> posts = postService.getAll();
        model.addAttribute("posts", posts);
        return "home";
    }

    @GetMapping("/about_us")
    private String aboutus() {
        return "about_us";
    }

    @GetMapping("/classes")
    private String classes() {
        return "classes";
    }

    @GetMapping("/blog")
    private String blog() {
        return "blog";
    }

    @GetMapping("/service")
    private String service() {
        return "service";
    }

    @GetMapping("/404")
    private String error() {
        return "404";
    }



    @GetMapping("/register")
    private String register(Model model) {
        UserEntity userEntity = new UserEntity();
            model.addAttribute("user", userEntity);
            if(userEntity.getRoleid() == 0){
                userEntity.setRoleid(1);
            }
        return "register";
    }

    @GetMapping("/adduser")
    public String addUser(Model model) {
        UserEntity userEntity = new UserEntity();
        model.addAttribute("user", userEntity);
        if(userEntity.getRoleid() == 0){
            userEntity.setRoleid(1);
        }
        return "adduser";
    }

    @GetMapping("/admin")
    public String listUser(Model model) {
        List<UserEntity> users = userServiceItf.getAll();
        model.addAttribute("users", users);
        return "admin";
    }

    @PostMapping("/logout")
    public String logoutUser(@ModelAttribute UserEntity userEntity, Model model) {
        userServiceItf.createUser(userEntity);
        return "redirect:/index";
    }
    @PostMapping("/register")
    public String registerUser(@ModelAttribute UserEntity userEntity) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String encodedPassword = encoder.encode(userEntity.getPassword());
        userEntity.setPassword(encodedPassword);
            userServiceItf.createUser(userEntity);
        return "redirect:/login";
    }
    @PostMapping("/adduser")
    public String addUser(@ModelAttribute UserEntity userEntity) {
        userServiceItf.createUser(userEntity);
        return "redirect:/admin";
    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable("id") int id, Model model) {
        userServiceItf.deleteUser(id);
        return "redirect:/admin";
    }

    @GetMapping("/edit/{id}")
    public String editUser(@PathVariable("id") int id, Model model) {
        Optional<UserEntity> userEdit = userServiceItf.findUserById(id);
        userEdit.ifPresent(user -> model.addAttribute("user", user));
        return "edituser";
    }
}
