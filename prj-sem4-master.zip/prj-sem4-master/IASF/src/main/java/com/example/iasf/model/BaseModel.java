package com.example.iasf.model;

public class BaseModel<T> {
    public int status = 1;
    public String message = "success";
    public T data;
}
