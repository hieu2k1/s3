package com.example.iasf.repository;

import com.example.iasf.entity.ExercisePackEntity;
import com.example.iasf.entity.PostEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ExercisePackRepo extends JpaRepository<ExercisePackEntity,Integer> {

    @Query("select p from ExercisePackEntity p where p.loaibaitap like %:loaibaitap%")
    List<ExercisePackEntity> findAllByName(String loaibaitap, Pageable pageable);
}
