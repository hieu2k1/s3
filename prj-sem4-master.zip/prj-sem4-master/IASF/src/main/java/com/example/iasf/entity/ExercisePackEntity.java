package com.example.iasf.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "ExercisePack")
public class ExercisePackEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int magoi;

    @Column(name = "loaibaitap")
    private String loaibaitap;

    @Column(name = "soluongbaitap")
    private String soluongbaitap;

    @Column(name = "thoigiantap")
    private String thoigiantap;

    @Column(name = "adminidupload")
    private int adminidupload;

    @ManyToOne
    @JoinColumn(name = "adminidupload", insertable = false, updatable = false)
    private UserEntity user;

    public int getMagoi() {
        return magoi;
    }

    public void setMagoi(int magoi) {
        this.magoi = magoi;
    }

    public String getLoaibaitap() {
        return loaibaitap;
    }

    public void setLoaibaitap(String loaibaitap) {
        this.loaibaitap = loaibaitap;
    }

    public String getSoluongbaitap() {
        return soluongbaitap;
    }

    public void setSoluongbaitap(String soluongbaitap) {
        this.soluongbaitap = soluongbaitap;
    }

    public String getThoigiantap() {
        return thoigiantap;
    }

    public void setThoigiantap(String thoigiantap) {
        this.thoigiantap = thoigiantap;
    }

    public int getAdminidupload() {
        return adminidupload;
    }

    public void setAdminidupload(int adminidupload) {
        this.adminidupload = adminidupload;
    }

    public UserEntity getUser() {
        return user;
    }

    public void setUser(UserEntity user) {
        this.user = user;
    }
}
