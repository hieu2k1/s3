package com.example.iasf.service;

import com.example.iasf.entity.ExercisePackEntity;
import com.example.iasf.repository.ExercisePackRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ExerciseServiceImpl implements ExerciseService{


    @Autowired
    ExercisePackRepo exercisePackRepo;

    @Override
    public ExercisePackEntity createExercise(ExercisePackEntity p) {
        return exercisePackRepo.save(p);
    }

    @Override
    public List<ExercisePackEntity> getAll() {
        return exercisePackRepo.findAll();
    }

    @Override
    public void deleteExercise(int id) {
        exercisePackRepo.deleteById(id);
    }

    @Override
    public Optional<ExercisePackEntity> findExerciseById(int id) {
        return exercisePackRepo.findById(id);
    }

    @Override
    public List<ExercisePackEntity> getExerciseByName(String nameExercise, Pageable pageable) {
        return exercisePackRepo.findAllByName(nameExercise,pageable);
    }

    @Override
    public List<ExercisePackEntity> getAllExercise(Pageable pageable) {
        return exercisePackRepo.findAll(pageable).getContent();
    }

    @Override
    public Page<ExercisePackEntity> findAll(Pageable pageable) {
        return exercisePackRepo.findAll(pageable);
    }
}