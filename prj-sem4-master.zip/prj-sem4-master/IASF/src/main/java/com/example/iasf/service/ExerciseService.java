package com.example.iasf.service;

import com.example.iasf.entity.ExercisePackEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ExerciseService {
    ExercisePackEntity createExercise(ExercisePackEntity p);
    List<ExercisePackEntity> getAll();
    void deleteExercise(int id);
    Optional<ExercisePackEntity> findExerciseById(int id);
    List<ExercisePackEntity> getExerciseByName(String nameExercise, Pageable pageable);
    List<ExercisePackEntity> getAllExercise(Pageable pageable);
    Page<ExercisePackEntity> findAll(Pageable pageable);
}
