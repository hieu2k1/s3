package com.example.iasf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IasfApplication {

	public static void main(String[] args) {
		SpringApplication.run(IasfApplication.class, args);
	}

}
