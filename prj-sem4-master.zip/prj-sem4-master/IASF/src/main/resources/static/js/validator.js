

function Validator(options){

    var selectorRules = {};


    function validate(inputElement, rule){
        var errorMessage;
        var errorElement = inputElement.parentElement.querySelector(options.errorSelector);

        var rules = selectorRules[rule.selector];

        for( var i =0; i < rules.length; ++i){
            errorMessage = rules[i](inputElement.value);
            if (errorMessage) break;
        }

        if (errorMessage){
            errorElement.innerText = errorMessage;
            inputElement.parentElement.classList.add('invalid');
        }else {
            errorElement.innerText = '';
            inputElement.parentElement.classList.remove('invalid');
        }
        return ! errorMessage;
    }

    var formElement = document.querySelector(options.form);

    console.log(options.rules);

    if (formElement){


        formElement.onsubmit = function(e){
            e.preventDefault();

            var isFormValid = true;


            options.rules.forEach(function (rule){
                var  inputElement = formElement.querySelector(rule.selector);
                var isValid = validate(inputElement, rule);
                if (!isValid) {
                    isFormValid = false;
                }
            });


            if (isFormValid) {
                if (typeof options.onsubmit === 'function'){

                    var enableInputs = formElement.querySelectorAll(['name']);

                    var formValues = Array.form(enableInputs).reduce(function(values,input){
                        return (value[input.name] = input.value) && values;
                    }, {});
                    options.onsubmit(formValues);

                }else{
                    formElement.submit();
                    window.alert('Đăng Kí Thành Công , Đi Tới Đăng Nhập ');
                }
            }
        }

        options.rules.forEach(function (rule){

            if (Array.isArray(selectorRules[rule.selector])) {
                selectorRules[rule.selector].push(rule.test);
            }else{
                selectorRules[rule.selector] = [rule.test];
            }
            var  inputElement = formElement.querySelector(rule.selector);

            if (inputElement){
                inputElement.onblur = function (){
                    validate(inputElement, rule);
                }
                inputElement.oninput = function(){
                    var errorElement = inputElement.parentElement.querySelector('.form-message');
                    errorElement.innerText = '';
                    inputElement.parentElement.classList.remove('invalid');
                }
            }
        });

        console.log(selectorRules);

    }

}

Validator.isRequired = function (selector){
    return{
        selector: selector,
        test: function (value){
            return value.trim() ? undefined : 'Vui lòng điền vào trường này !'
        }
    };
}

Validator.isConfirmed = function(selector , getConfirm , msg){
    return{
        selector: selector,
        test: function(value){
            return value === getConfirm() ? undefined : msg || 'Giá trị nhập vào không chính xác !';
        }
    }
}
Validator.isEmail = function (selector, msg){
    return{
        selector: selector,
        test: function (value){
            var regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
            return regex.test(value) ? undefined : msg || 'Trường này phải là email';
        }
    };
}

Validator.minLength = function (selector, min){
    return {
        selector: selector,
        test: function (value){
            return value.length >= min ? undefined : 'Mật khẩu phải có đủ 6 kí tự !';
        }
    };
}

Validator.isPhone = function (selector, min){
    return {
        selector: selector,
        test: function (value){
            return value.length >= min && value.trim() <= 2147483647 ? undefined : 'Số điện thoại phải từ 10 số và không quá 2147483647 !';
        }
    };
}
Validator.isValidrole = function (selector){
    return{
        selector: selector,
        test: function (value){
            return value.trim() != 1 ? 'Không được thay đổi trường này , Bạn chỉ có thể đăng kí với quyền người dùng !' : undefined ;
        }
    };
}
Validator.isPhoneCheck = function (selector, min){
    return {
        selector: selector,
        test: function (value){
            return value.length <= min ? 'Vui lòng nhập số điện thoại !' : undefined ;
        }
    };
}